package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AdminHomeScreen
import com.example.ui.DsfHomeScreen
import com.example.ui.LoginScreen
import com.example.ui.SalesViewModel
import com.example.ui.Screen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        val viewModel: SalesViewModel = viewModel()
        val currentScreen by viewModel.currentScreen.collectAsState()

        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
          BoxWithNavigation(
              viewModel = viewModel,
              currentScreen = currentScreen,
              modifier = Modifier.padding(innerPadding)
          )
        }
      }
    }
  }
}

@Composable
fun BoxWithNavigation(
    viewModel: SalesViewModel,
    currentScreen: Screen,
    modifier: Modifier = Modifier
) {
    when (currentScreen) {
        Screen.LOGIN -> LoginScreen(viewModel = viewModel, modifier = modifier)
        Screen.DSF_HOME -> DsfHomeScreen(viewModel = viewModel, modifier = modifier)
        Screen.ADMIN_HOME -> AdminHomeScreen(viewModel = viewModel, modifier = modifier)
    }
}

