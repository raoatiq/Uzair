package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.MedicalStore
import com.example.data.OrderItem
import com.example.data.StoreVisit
import com.example.ui.theme.*
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DsfHomeScreen(
    viewModel: SalesViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val activeTab by viewModel.dsfTab.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = (currentUser?.username ?: "DSF PORTAL").uppercase(Locale.getDefault()),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            text = "BASE STATION: ${(currentUser?.baseStation ?: "").uppercase(Locale.getDefault())}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.logout() }) {
                        Icon(Icons.Filled.Logout, contentDescription = "Logout", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = GoogleBlue)
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = activeTab == DsfTab.WORK,
                    onClick = { viewModel.setDsfTab(DsfTab.WORK) },
                    icon = { Icon(Icons.Filled.Storefront, contentDescription = "Work Tab") },
                    label = { Text("AREA & ORDERS", fontWeight = FontWeight.Bold, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GoogleBlue,
                        selectedTextColor = GoogleBlue,
                        indicatorColor = GoogleBlueLight
                    )
                )
                NavigationBarItem(
                    selected = activeTab == DsfTab.SALES,
                    onClick = { viewModel.setDsfTab(DsfTab.SALES) },
                    icon = { Icon(Icons.Filled.Analytics, contentDescription = "Sales Tab") },
                    label = { Text("SALES & VISITS", fontWeight = FontWeight.Bold, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GoogleBlue,
                        selectedTextColor = GoogleBlue,
                        indicatorColor = GoogleBlueLight
                    )
                )
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                DsfTab.WORK -> DsfWorkTab(viewModel)
                DsfTab.SALES -> DsfSalesTab(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DsfWorkTab(viewModel: SalesViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val selectedArea by viewModel.dsfSelectedWorkingArea.collectAsState()
    val selectedStore by viewModel.selectedMedicalStore.collectAsState()
    val filteredStores by viewModel.filteredMedicalStores.collectAsState()
    val storeSearchQuery by viewModel.storeSearchQuery.collectAsState()
    val isAddingNewStore by viewModel.isAddingNewStore.collectAsState()
    val newStoreName by viewModel.newStoreName.collectAsState()

    val locationShared by viewModel.locationShared.collectAsState()
    val currentAddress by viewModel.currentAddress.collectAsState()
    val currentLat by viewModel.currentLatitude.collectAsState()
    val currentLng by viewModel.currentLongitude.collectAsState()

    val capturedPhoto by viewModel.capturedPhoto.collectAsState()
    val hasOrderSelection by viewModel.hasOrderSelection.collectAsState()
    val orderQuantities by viewModel.orderQuantities.collectAsState()

    var isAreaDropdownExpanded by remember { mutableStateOf(false) }
    var isStoreDropdownExpanded by remember { mutableStateOf(false) }
    var showCameraSimDialog by remember { mutableStateOf(false) }

    val areasList = currentUser?.baseStation?.let { viewModel.baseStationsMap[it] } ?: emptyList()
    val decimalFormat = DecimalFormat("#,##0.00")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Step 1: Select Working Area
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(20.dp),
            elevation = CardDefaults.cardElevation(2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "1. SELECT WORKING AREA",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                    color = GoogleBlue,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                ExposedDropdownMenuBox(
                    expanded = isAreaDropdownExpanded,
                    onExpandedChange = { isAreaDropdownExpanded = !isAreaDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = if (selectedArea.isEmpty()) "SELECT TERRITORY / WORKING AREA" else selectedArea.uppercase(Locale.getDefault()),
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isAreaDropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoogleBlue,
                            unfocusedBorderColor = Color.LightGray
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = isAreaDropdownExpanded,
                        onDismissRequest = { isAreaDropdownExpanded = false }
                    ) {
                        areasList.forEach { area ->
                            DropdownMenuItem(
                                text = { Text(area.uppercase(Locale.getDefault()), fontWeight = FontWeight.Bold) },
                                onClick = {
                                    viewModel.setDsfSelectedWorkingArea(area)
                                    isAreaDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Step 2: Select or Add Medical Store
        if (selectedArea.isNotEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "2. SELECT / ADD MEDICAL STORE",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        color = GoogleBlue,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    if (!isAddingNewStore) {
                        // Dropdown selection
                        ExposedDropdownMenuBox(
                            expanded = isStoreDropdownExpanded,
                            onExpandedChange = { isStoreDropdownExpanded = !isStoreDropdownExpanded },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = selectedStore?.name?.uppercase(Locale.getDefault()) ?: "SEARCH AND SELECT STORE",
                                onValueChange = { viewModel.setStoreSearchQuery(it) },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isStoreDropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoogleBlue,
                                    unfocusedBorderColor = Color.LightGray
                                )
                            )
                            ExposedDropdownMenu(
                                expanded = isStoreDropdownExpanded,
                                onDismissRequest = { isStoreDropdownExpanded = false }
                            ) {
                                if (filteredStores.isEmpty()) {
                                    DropdownMenuItem(
                                        text = { Text("NO STORES FOUND IN THIS AREA. PLEASE ADD ONE.", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                        onClick = {}
                                    )
                                } else {
                                    filteredStores.forEach { store ->
                                        DropdownMenuItem(
                                            text = { Text(store.name.uppercase(Locale.getDefault()), fontWeight = FontWeight.Bold) },
                                            onClick = {
                                                viewModel.selectMedicalStore(store)
                                                isStoreDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Button to switch to Add Store Mode
                        OutlinedButton(
                            onClick = { viewModel.setIsAddingNewStore(true) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = GoogleBlue),
                            shape = RoundedCornerShape(26.dp)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = "Add Store")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("STORE NOT LISTED? ADD NEW STORE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    } else {
                        // Add New Store input
                        Text(
                            text = "ADD NEW MEDICAL STORE",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp,
                            color = GoogleSlate
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = newStoreName,
                            onValueChange = { viewModel.setNewStoreName(it) },
                            placeholder = { Text("ENTER MEDICAL STORE NAME") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoogleBlue,
                                unfocusedBorderColor = Color.LightGray
                            )
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { viewModel.setIsAddingNewStore(false) }) {
                                Text("CANCEL", color = GoogleSlate, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Button(
                                onClick = { viewModel.addNewMedicalStore() },
                                colors = ButtonDefaults.buttonColors(containerColor = GoogleBlue),
                                shape = RoundedCornerShape(24.dp),
                                enabled = newStoreName.trim().isNotEmpty()
                            ) {
                                Text("ADD & SELECT", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Location & Picture & Order Steps
        if (selectedStore != null) {
            // Location
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "3. AUDIT & CHECK-IN",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        color = GoogleBlue,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Location share
                    if (!locationShared) {
                        Button(
                            onClick = { viewModel.shareLocation() },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GoogleTeal),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Icon(Icons.Filled.LocationOn, contentDescription = "Pin")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("SHARE YOUR CURRENT LOCATION", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    } else {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(GoogleGreenLight, RoundedCornerShape(14.dp))
                                .border(1.dp, GoogleGreen, RoundedCornerShape(14.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.CheckCircle, contentDescription = "Verified", tint = GoogleGreen)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "LOCATION SHARED SUCCESSFULLY",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = GoogleGreen
                                )
                                Text(
                                    text = "LAT: ${String.format("%.4f", currentLat)}, LNG: ${String.format("%.4f", currentLng)}",
                                    fontSize = 11.sp,
                                    color = GoogleTextDark,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = currentAddress.uppercase(Locale.getDefault()),
                                    fontSize = 11.sp,
                                    color = GoogleSlate,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Picture Capture
                    if (capturedPhoto == null) {
                        Button(
                            onClick = { showCameraSimDialog = true },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GoogleSlate),
                            shape = RoundedCornerShape(24.dp),
                            enabled = locationShared // require location first
                        ) {
                            Icon(Icons.Filled.CameraAlt, contentDescription = "Camera")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("CAPTURE STOREFRONT PICTURE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    } else {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(GoogleBlueLight, RoundedCornerShape(14.dp))
                                .border(1.dp, GoogleBlue, RoundedCornerShape(14.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Image, contentDescription = "Photo Captured", tint = GoogleBlue)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "STOREFRONT PICTURE ATTACHED",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = GoogleBlue
                                )
                                Text(
                                    text = "CODE: ${capturedPhoto?.uppercase(Locale.getDefault())}",
                                    fontSize = 11.sp,
                                    color = GoogleSlate,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            TextButton(onClick = { showCameraSimDialog = true }) {
                                Text("RETAKE", color = GoogleBlue, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Have you got order selection
        if (capturedPhoto != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "4. HAVE YOU GOT ANY ORDER?",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        color = GoogleBlue,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Yes Card Button
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (hasOrderSelection == true) GoogleBlueLight else GoogleLightGray.copy(alpha = 0.5f)
                            ),
                            border = if (hasOrderSelection == true) borderStroke(1.5.dp, GoogleBlue) else null,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { viewModel.setHasOrderSelection(true) }
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    Icons.Filled.Check,
                                    contentDescription = "Yes",
                                    tint = if (hasOrderSelection == true) GoogleBlue else GoogleSlate
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "YES",
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (hasOrderSelection == true) GoogleBlue else GoogleTextDark
                                )
                            }
                        }

                        // No Card Button
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (hasOrderSelection == false) GoogleRed.copy(alpha = 0.1f) else GoogleLightGray.copy(alpha = 0.5f)
                            ),
                            border = if (hasOrderSelection == false) borderStroke(1.5.dp, GoogleRed) else null,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    viewModel.setHasOrderSelection(false)
                                }
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    Icons.Filled.Close,
                                    contentDescription = "No",
                                    tint = if (hasOrderSelection == false) GoogleRed else GoogleSlate
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "NO",
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (hasOrderSelection == false) GoogleRed else GoogleTextDark
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Order Booking module
        if (hasOrderSelection == true) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "5. ORDER BOOKING SHEET",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        color = GoogleBlue,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "SPECIFY PACK QUANTITIES FOR THE PRODUCTS BELOW",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoogleSlate,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Products List with quantity selectors
                    viewModel.productsList.forEach { product ->
                        val qty = orderQuantities[product.name] ?: 0
                        val lineTotal = qty * product.tradePrice

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.5f)) {
                                Text(
                                    text = product.name.uppercase(Locale.getDefault()),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = GoogleTextDark
                                )
                                Text(
                                    text = "TRADE PRICE: PKR ${decimalFormat.format(product.tradePrice)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = GoogleSlate
                                )
                                if (qty > 0) {
                                    Text(
                                        text = "SUBTOTAL: PKR ${decimalFormat.format(lineTotal)}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = GoogleGreen
                                    )
                                }
                            }

                            // Quantity Selector Controls (+ / -)
                            Row(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = { viewModel.updateProductQuantity(product.name, qty - 1) },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(GoogleLightGray, CircleShape)
                                ) {
                                    Icon(Icons.Filled.Remove, contentDescription = "Decrease", modifier = Modifier.size(16.dp))
                                }

                                Text(
                                    text = qty.toString(),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 14.sp,
                                    modifier = Modifier.padding(horizontal = 12.dp),
                                    textAlign = TextAlign.Center
                                )

                                IconButton(
                                    onClick = { viewModel.updateProductQuantity(product.name, qty + 1) },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(GoogleBlueLight, CircleShape)
                                ) {
                                    Icon(Icons.Filled.Add, contentDescription = "Increase", modifier = Modifier.size(16.dp), tint = GoogleBlue)
                                }
                            }
                        }
                        Divider(color = Color.LightGray.copy(alpha = 0.4f))
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Compute dynamic Booking total value
                    var totalOrderValue = 0.0
                    var totalItemsBooked = 0
                    for ((prod, qty) in orderQuantities) {
                        val product = viewModel.productsList.find { it.name == prod } ?: continue
                        totalOrderValue += qty * product.tradePrice
                        totalItemsBooked += qty
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = GoogleGreenLight),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("TOTAL UNITS:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoogleGreen)
                                Text("$totalItemsBooked PACKS", fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, color = GoogleGreen)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("TOTAL BOOKING:", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = GoogleGreen)
                                Text("PKR ${decimalFormat.format(totalOrderValue)}", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = GoogleGreen)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Bottom final Submit button
        if (hasOrderSelection != null) {
            val orderIsOk = if (hasOrderSelection == true) orderQuantities.isNotEmpty() else true
            Button(
                onClick = { viewModel.submitVisitAndBooking() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GoogleBlue),
                shape = RoundedCornerShape(26.dp),
                enabled = orderIsOk
            ) {
                Icon(Icons.Filled.Send, contentDescription = "Submit")
                Spacer(modifier = Modifier.width(8.dp))
                Text("SUBMIT VISIT & BOOKING DETAILS", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            }
        }
    }

    // Camera Simulation Selection Dialog
    if (showCameraSimDialog) {
        Dialog(onDismissRequest = { showCameraSimDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Filled.CameraAlt,
                        contentDescription = "Camera Simulation",
                        tint = GoogleBlue,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "CAMERA SIMULATION",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "SIMULATE SNAPPING AN AUDIT PHOTO OF THE MEDICAL STORE STOREFRONT.",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoogleSlate,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            viewModel.capturePicture(0)
                            showCameraSimDialog = false
                        },
                        modifier = Modifier.fillMaxWidth().height(44.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GoogleBlue),
                        shape = RoundedCornerShape(22.dp)
                    ) {
                        Text("SIMULATE STORE FRONT VIEW", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            viewModel.capturePicture(1)
                            showCameraSimDialog = false
                        },
                        modifier = Modifier.fillMaxWidth().height(44.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GoogleTeal),
                        shape = RoundedCornerShape(22.dp)
                    ) {
                        Text("SIMULATE INTERIOR RACK LAYOUT", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            viewModel.capturePicture(2)
                            showCameraSimDialog = false
                        },
                        modifier = Modifier.fillMaxWidth().height(44.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GoogleSlate),
                        shape = RoundedCornerShape(22.dp)
                    ) {
                        Text("SIMULATE CLOSE-UP STORE COUNTER", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun DsfSalesTab(viewModel: SalesViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val allVisits by viewModel.allVisits.collectAsState()
    val allOrderItems by viewModel.allOrderItems.collectAsState()

    val dsfVisits = remember(allVisits, currentUser) {
        currentUser?.let { user ->
            allVisits.filter { it.dsfId == user.id }
        } ?: emptyList()
    }

    val dsfOrders = remember(allOrderItems, currentUser) {
        currentUser?.let { user ->
            allOrderItems.filter { it.dsfId == user.id }
        } ?: emptyList()
    }

    // Calculations
    val totalVisited = dsfVisits.size
    val productiveVisited = dsfVisits.count { it.hasOrder }
    val totalRevenue = dsfVisits.sumOf { it.totalOrderValue }

    val decimalFormat = DecimalFormat("#,##0.00")
    val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "PERFORMANCE OVERVIEW",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = GoogleTextDark,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // KPI Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Total Visits Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = GoogleBlueLight),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Icon(Icons.Filled.Storefront, contentDescription = "Visits", tint = GoogleBlue)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("TOTAL VISITED", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoogleSlate)
                        Text("$totalVisited STORES", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = GoogleBlueDark)
                    }
                }

                // Productive Visits Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = GoogleGreenLight),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = "Productive", tint = GoogleGreen)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("PRODUCTIVE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoogleSlate)
                        Text("$productiveVisited STORES", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = GoogleGreen)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Revenue Booked Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GoogleTealLight),
                shape = RoundedCornerShape(20.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("TOTAL SALES REVENUE BOOKED", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoogleTeal)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("PKR ${decimalFormat.format(totalRevenue)}", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = GoogleTeal)
                    }
                    Icon(
                        Icons.Filled.Leaderboard,
                        contentDescription = "Revenue",
                        tint = GoogleTeal,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Sub title
            Text(
                text = "PRODUCT-WISE BOOKINGS",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = GoogleTextDark,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            if (dsfOrders.isEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                ) {
                    Text(
                        text = "NO PRODUCTS BOOKED YET",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoogleSlate,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                // Group by Product Name
                val productSummaries = dsfOrders.groupBy { it.productName }
                    .map { (name, items) ->
                        val qty = items.sumOf { it.quantity }
                        val value = items.sumOf { it.totalPrice }
                        Triple(name, qty, value)
                    }.sortedByDescending { it.third }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(1.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        productSummaries.forEach { (prodName, qty, value) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1.5f)) {
                                    Text(
                                        text = prodName.uppercase(Locale.getDefault()),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = GoogleTextDark
                                    )
                                    Text(
                                        text = "$qty PACKS ORDERED",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GoogleSlate
                                    )
                                }
                                Text(
                                    text = "PKR ${decimalFormat.format(value)}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = GoogleTeal,
                                    modifier = Modifier.weight(1f),
                                    textAlign = TextAlign.End
                                )
                            }
                            Divider(color = Color.LightGray.copy(alpha = 0.3f))
                        }
                    }
                }
            }

            Text(
                text = "RECENT VISIT AUDITS",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = GoogleTextDark,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        if (dsfVisits.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "NO VISIT AUDITS LOGGED YET",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoogleSlate,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(dsfVisits) { visit ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column {
                                Text(
                                    text = visit.storeName.uppercase(Locale.getDefault()),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 14.sp,
                                    color = GoogleTextDark
                                )
                                Text(
                                    text = "WORKING AREA: ${visit.workingArea.uppercase(Locale.getDefault())}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoogleBlueDark
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (visit.hasOrder) GoogleGreenLight else GoogleLightGray)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (visit.hasOrder) "PRODUCTIVE" else "NON-PROD",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 10.sp,
                                    color = if (visit.hasOrder) GoogleGreen else GoogleSlate
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "BASE STATION: ${visit.baseStation.uppercase(Locale.getDefault())}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoogleSlate
                            )
                            Text(
                                text = dateFormat.format(Date(visit.timestamp)).uppercase(Locale.getDefault()),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoogleSlate
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Divider(color = Color.LightGray.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            verticalAlignment = Alignment.Top,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                Icons.Filled.PinDrop,
                                contentDescription = "Map Location",
                                tint = GoogleRed,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = "GEOTAGGED ADDRESS:",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = GoogleTextDark
                                )
                                Text(
                                    text = visit.address.uppercase(Locale.getDefault()),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoogleSlate,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "GPS: LAT ${String.format("%.5f", visit.latitude)}, LNG ${String.format("%.5f", visit.longitude)}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoogleBlue
                                )
                            }
                        }

                        visit.photoBase64?.let { photo ->
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(GoogleLightGray)
                                    .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(GoogleBlueLight, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Filled.Store,
                                        contentDescription = "Store Photo",
                                        tint = GoogleBlue
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "STOREFRONT PICTURE AUDIT",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = GoogleTextDark
                                    )
                                    Text(
                                        text = "VERIFIED IMAGE: ${photo.uppercase(Locale.getDefault())}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GoogleSlate
                                    )
                                }
                            }
                        }

                        if (visit.hasOrder && visit.totalOrderValue > 0) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = GoogleGreenLight.copy(alpha = 0.3f)),
                                border = borderStroke(1.dp, GoogleGreen.copy(alpha = 0.3f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "ORDER SUMMARY BOOKED",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = GoogleGreen
                                        )
                                        Text(
                                            text = "TOTAL VALUE: PKR ${decimalFormat.format(visit.totalOrderValue)}",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = GoogleGreen
                                        )
                                    }
                                    Icon(Icons.Filled.CheckCircle, contentDescription = "Ok", tint = GoogleGreen)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Utility stroke border creator
@Composable
fun borderStroke(width: androidx.compose.ui.unit.Dp, color: Color) =
    androidx.compose.foundation.BorderStroke(width, color)
