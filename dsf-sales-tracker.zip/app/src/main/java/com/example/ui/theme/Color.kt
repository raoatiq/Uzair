package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GoogleBlue = Color(0xFF1EA1E1) // Curexa Sky Blue
val GoogleBlueLight = Color(0xFFE1F5FE) // Curexa Sky Blue Light
val GoogleBlueDark = Color(0xFF0288D1) // Curexa Sky Blue Dark
val GoogleTeal = Color(0xFFF58220) // Highnoon Sunset Orange
val GoogleTealLight = Color(0xFFFFF3E0) // Highnoon Orange Light
val GoogleSlate = Color(0xFF53565A) // Elegant Dark Slate Grey (Highnoon logo text)
val GoogleLightGray = Color(0xFFECEFF1) // Light background/border grey
val GoogleBg = Color(0xFFF5F7FA) // Elegant soft off-white background
val GoogleTextDark = Color(0xFF263238) // Dark Slate for high-contrast text
val GoogleGreen = Color(0xFF2E7D32) // Professional forest green
val GoogleGreenLight = Color(0xFFE8F5E9) // Very soft green background
val GoogleRed = Color(0xFFD32F2F) // Warning/error red
val GoogleOrange = Color(0xFFF58220) // Highnoon Sunset Orange

// Backward compatibility or legacy colors if referenced anywhere
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

