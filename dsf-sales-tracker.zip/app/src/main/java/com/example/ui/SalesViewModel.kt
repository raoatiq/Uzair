package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.DsfUser
import com.example.data.MedicalStore
import com.example.data.OrderItem
import com.example.data.SalesRepository
import com.example.data.StoreVisit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Screen {
    LOGIN,
    DSF_HOME,
    ADMIN_HOME
}

enum class DsfTab {
    WORK,  // Working Area & Orders
    SALES  // Sales & Visits
}

enum class AdminTab {
    MONITOR, // DSF Monitoring
    SALES,   // Sales Dashboard
    USERS    // User Management
}

data class Product(
    val id: String,
    val name: String,
    val tradePrice: Double
)

class SalesViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: SalesRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = SalesRepository(database.salesDao())
        
        // Populate default data if database is empty
        viewModelScope.launch {
            repository.allDsfUsers.collect { users ->
                if (users.isEmpty()) {
                    prepopulateData()
                }
            }
        }
    }

    // List of products and prices
    val productsList = listOf(
        Product("1", "AZIPOS 200MG/5ML DRY", 219.39),
        Product("2", "AZIPOS 250MG CAPS 10S (Pack A)", 398.87),
        Product("3", "AZIPOS 250MG CAPS 10S (Pack B)", 351.77),
        Product("4", "AZIPOS 500MG TAB 6S", 346.78),
        Product("5", "HINOCAM 20MG TABLET", 294.95),
        Product("6", "MOBLO 500MCG", 383.35),
        Product("7", "MOBLO 500MCG TABLET", 277.10),
        Product("8", "MONTIT 10MG TAB 14S", 340.00),
        Product("9", "OMEVEX IV INJECTION", 331.50),
        Product("10", "OMSTA 20MG CAPSULE (A)", 191.47),
        Product("11", "OMSTA 20MG CAPSULE (B)", 191.47),
        Product("12", "PROSTAM 0.4MG CAPS 28S", 1049.75),
        Product("13", "VOXIQUIN 250 MG TAB", 204.00),
        Product("14", "VOXIQUIN 500 MG TAB (A)", 352.75),
        Product("15", "VOXIQUIN 500 MG TAB (B)", 242.25)
    )

    // Base Stations and Working Areas Map
    val baseStationsMap = mapOf(
        "HYDERABAD-1" to listOf(
            "Tando Allahyar", "Matli", "Tando jam", "Saddar", "Qasimabad", "Jail Road", "Thana Bhola khan"
        ),
        "Hyderabad-2" to listOf(
            "Kotri", "Latifabad", "Matyari", "Saeedabad", "Hala", "Bhit Shah", "Shahdadpur", "Tando Adam", "Sanghar", "Badin", "Talhar", "Tando Bhago"
        ),
        "Nawab Shah" to listOf(
            "Hospital raod", "Sakrand raod", "Masjid raod", "Sakran", "Qazi Ahmed", "Moro", "Dulat pur", "Nawab Ali Muhammad", "Daur", "Bhadhi", "Padidan", "Bharia raod", "Akri", "Korandi", "Pirwasan", "Shapur chakra", "Khadro", "Sarhari", "Maqsodo", "Karnal 60mail", "Manwabad", "Old Nawabshah"
        ),
        "Mirpurkhas" to listOf(
            "Khipro", "Degree", "Jhudoo", "Shadi pali", "Kgm", "Sindhri", "Nokot", "MPK City"
        ),
        "Noshero Feroz" to listOf(
            "Noshero City", "Kardairo", "Bharia city", "Tharo shah", "New jatoi", "mithyni"
        ),
        "Umar Kot" to listOf(
            "Umer kot City", "Nangar parkar", "Samro city", "Mithi", "Islam kot", "Khokara par"
        )
    )

    // Flows from database
    val dsfUsers: StateFlow<List<DsfUser>> = repository.allDsfUsers.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val allVisits: StateFlow<List<StoreVisit>> = repository.allVisits.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val allOrderItems: StateFlow<List<OrderItem>> = repository.allOrderItems.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val allMedicalStores: StateFlow<List<MedicalStore>> = repository.allMedicalStores.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // Navigation and tabs state
    private val _currentScreen = MutableStateFlow(Screen.LOGIN)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _dsfTab = MutableStateFlow(DsfTab.WORK)
    val dsfTab: StateFlow<DsfTab> = _dsfTab.asStateFlow()

    private val _adminTab = MutableStateFlow(AdminTab.MONITOR)
    val adminTab: StateFlow<AdminTab> = _adminTab.asStateFlow()

    // Login screen states
    private val _loginBaseStation = MutableStateFlow("HYDERABAD-1")
    val loginBaseStation: StateFlow<String> = _loginBaseStation.asStateFlow()

    private val _loginUsername = MutableStateFlow("")
    val loginUsername: StateFlow<String> = _loginUsername.asStateFlow()

    private val _loginPassword = MutableStateFlow("")
    val loginPassword: StateFlow<String> = _loginPassword.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    private val _currentUser = MutableStateFlow<DsfUser?>(null)
    val currentUser: StateFlow<DsfUser?> = _currentUser.asStateFlow()

    // DSF Workflow states
    private val _dsfSelectedWorkingArea = MutableStateFlow("")
    val dsfSelectedWorkingArea: StateFlow<String> = _dsfSelectedWorkingArea.asStateFlow()

    private val _storeSearchQuery = MutableStateFlow("")
    val storeSearchQuery: StateFlow<String> = _storeSearchQuery.asStateFlow()

    private val _selectedMedicalStore = MutableStateFlow<MedicalStore?>(null)
    val selectedMedicalStore: StateFlow<MedicalStore?> = _selectedMedicalStore.asStateFlow()

    private val _newStoreName = MutableStateFlow("")
    val newStoreName: StateFlow<String> = _newStoreName.asStateFlow()

    private val _isAddingNewStore = MutableStateFlow(false)
    val isAddingNewStore: StateFlow<Boolean> = _isAddingNewStore.asStateFlow()

    private val _locationShared = MutableStateFlow(false)
    val locationShared: StateFlow<Boolean> = _locationShared.asStateFlow()

    private val _currentLatitude = MutableStateFlow(0.0)
    val currentLatitude: StateFlow<Double> = _currentLatitude.asStateFlow()

    private val _currentLongitude = MutableStateFlow(0.0)
    val currentLongitude: StateFlow<Double> = _currentLongitude.asStateFlow()

    private val _currentAddress = MutableStateFlow("")
    val currentAddress: StateFlow<String> = _currentAddress.asStateFlow()

    private val _capturedPhoto = MutableStateFlow<String?>(null) // Base64 simulated photo
    val capturedPhoto: StateFlow<String?> = _capturedPhoto.asStateFlow()

    private val _hasOrderSelection = MutableStateFlow<Boolean?>(null) // Yes / No
    val hasOrderSelection: StateFlow<Boolean?> = _hasOrderSelection.asStateFlow()

    // Quantities mapped by Product Name
    private val _orderQuantities = MutableStateFlow<Map<String, Int>>(emptyMap())
    val orderQuantities: StateFlow<Map<String, Int>> = _orderQuantities.asStateFlow()

    // Dynamic Filtered Stores list
    val filteredMedicalStores: StateFlow<List<MedicalStore>> = combine(
        allMedicalStores,
        _currentUser,
        _dsfSelectedWorkingArea,
        _storeSearchQuery
    ) { stores, user, area, query ->
        if (user == null || area.isEmpty()) emptyList()
        else {
            stores.filter {
                it.baseStation.lowercase() == user.baseStation.lowercase() &&
                it.workingArea.lowercase() == area.lowercase() &&
                (query.isEmpty() || it.name.lowercase().contains(query.lowercase()))
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Admin UI states
    private val _newDsfUsername = MutableStateFlow("")
    val newDsfUsername: StateFlow<String> = _newDsfUsername.asStateFlow()

    private val _newDsfPassword = MutableStateFlow("")
    val newDsfPassword: StateFlow<String> = _newDsfPassword.asStateFlow()

    private val _newDsfBaseStation = MutableStateFlow("HYDERABAD-1")
    val newDsfBaseStation: StateFlow<String> = _newDsfBaseStation.asStateFlow()

    private val _adminSuccessMessage = MutableStateFlow<String?>(null)
    val adminSuccessMessage: StateFlow<String?> = _adminSuccessMessage.asStateFlow()

    private val _adminErrorMessage = MutableStateFlow<String?>(null)
    val adminErrorMessage: StateFlow<String?> = _adminErrorMessage.asStateFlow()

    private val _adminSelectedDsfFilter = MutableStateFlow<Long?>(null) // Null means all DSFs
    val adminSelectedDsfFilter: StateFlow<Long?> = _adminSelectedDsfFilter.asStateFlow()

    // Setters
    fun setLoginBaseStation(station: String) { _loginBaseStation.value = station }
    fun setLoginUsername(name: String) { _loginUsername.value = name }
    fun setLoginPassword(pass: String) { _loginPassword.value = pass }
    fun setDsfTab(tab: DsfTab) { _dsfTab.value = tab }
    fun setAdminTab(tab: AdminTab) { _adminTab.value = tab }
    fun setDsfSelectedWorkingArea(area: String) {
        _dsfSelectedWorkingArea.value = area
        _selectedMedicalStore.value = null
        _isAddingNewStore.value = false
        _locationShared.value = false
        _capturedPhoto.value = null
        _hasOrderSelection.value = null
        _orderQuantities.value = emptyMap()
    }
    fun setStoreSearchQuery(query: String) { _storeSearchQuery.value = query }
    fun selectMedicalStore(store: MedicalStore?) {
        _selectedMedicalStore.value = store
        _locationShared.value = false
        _capturedPhoto.value = null
        _hasOrderSelection.value = null
        _orderQuantities.value = emptyMap()
    }
    fun setIsAddingNewStore(adding: Boolean) {
        _isAddingNewStore.value = adding
        if (adding) _selectedMedicalStore.value = null
    }
    fun setNewStoreName(name: String) { _newStoreName.value = name }
    fun setHasOrderSelection(has: Boolean?) { _hasOrderSelection.value = has }
    fun updateProductQuantity(productName: String, qty: Int) {
        val currentMap = _orderQuantities.value.toMutableMap()
        if (qty <= 0) {
            currentMap.remove(productName)
        } else {
            currentMap[productName] = qty
        }
        _orderQuantities.value = currentMap
    }

    fun setAdminSelectedDsfFilter(dsfId: Long?) { _adminSelectedDsfFilter.value = dsfId }
    fun setNewDsfUsername(name: String) { _newDsfUsername.value = name }
    fun setNewDsfPassword(pass: String) { _newDsfPassword.value = pass }
    fun setNewDsfBaseStation(station: String) { _newDsfBaseStation.value = station }

    // Actions
    fun login() {
        _loginError.value = null
        val username = _loginUsername.value.trim()
        val password = _loginPassword.value.trim()
        val baseStation = _loginBaseStation.value

        if (username.isEmpty() || password.isEmpty()) {
            _loginError.value = "Please fill in all fields"
            return
        }

        // Admin login check
        if (username.lowercase() == "admin" && password == "admin123") {
            _currentUser.value = null
            _currentScreen.value = Screen.ADMIN_HOME
            _loginUsername.value = ""
            _loginPassword.value = ""
            return
        }

        // DSF check
        viewModelScope.launch {
            val user = repository.getDsfUserByUsername(username)
            if (user != null && user.password == password && user.baseStation == baseStation) {
                _currentUser.value = user
                _currentScreen.value = Screen.DSF_HOME
                _dsfSelectedWorkingArea.value = ""
                _loginUsername.value = ""
                _loginPassword.value = ""
            } else {
                _loginError.value = "Invalid Username or Password for selected Base Station"
            }
        }
    }

    fun logout() {
        _currentUser.value = null
        _currentScreen.value = Screen.LOGIN
        _dsfSelectedWorkingArea.value = ""
        _selectedMedicalStore.value = null
        _locationShared.value = false
        _capturedPhoto.value = null
        _hasOrderSelection.value = null
        _orderQuantities.value = emptyMap()
    }

    fun addNewMedicalStore() {
        val name = _newStoreName.value.trim()
        val user = _currentUser.value ?: return
        val area = _dsfSelectedWorkingArea.value

        if (name.isEmpty() || area.isEmpty()) return

        viewModelScope.launch {
            val storeId = repository.insertMedicalStore(
                MedicalStore(
                    name = name,
                    baseStation = user.baseStation,
                    workingArea = area
                )
            )
            val newStore = MedicalStore(id = storeId, name = name, baseStation = user.baseStation, workingArea = area)
            _selectedMedicalStore.value = newStore
            _isAddingNewStore.value = false
            _newStoreName.value = ""
        }
    }

    fun shareLocation() {
        val area = _dsfSelectedWorkingArea.value
        if (area.isEmpty()) return

        // Generate highly realistic Pakistan location based on selected area
        val (lat, lng, addr) = generateMockLocation(area)
        _currentLatitude.value = lat
        _currentLongitude.value = lng
        _currentAddress.value = addr
        _locationShared.value = true
    }

    fun capturePicture(simulatedTemplateId: Int) {
        // Base64 simulated photo strings depicting various store visuals
        val simulatedStores = listOf(
            "STORE_TEMP_A", // Modern Pharmacy
            "STORE_TEMP_B", // Standard Chemist
            "STORE_TEMP_C"  // Rural Medical Store
        )
        _capturedPhoto.value = simulatedStores.getOrElse(simulatedTemplateId) { "STORE_TEMP_A" }
    }

    fun submitVisitAndBooking() {
        val user = _currentUser.value ?: return
        val area = _dsfSelectedWorkingArea.value
        val store = _selectedMedicalStore.value ?: return
        val hasOrder = _hasOrderSelection.value ?: false
        val quantities = _orderQuantities.value

        val timestamp = System.currentTimeMillis()

        viewModelScope.launch {
            // Compute total order value
            var totalValue = 0.0
            val orderedItems = mutableListOf<OrderItem>()

            if (hasOrder) {
                for ((prodName, qty) in quantities) {
                    val product = productsList.find { it.name == prodName } ?: continue
                    val lineTotal = qty * product.tradePrice
                    totalValue += lineTotal
                    orderedItems.add(
                        OrderItem(
                            visitId = 0, // will set later
                            dsfId = user.id,
                            storeName = store.name,
                            productName = prodName,
                            quantity = qty,
                            tradePrice = product.tradePrice,
                            totalPrice = lineTotal,
                            timestamp = timestamp
                        )
                    )
                }
            }

            // Insert visit
            val visitId = repository.insertStoreVisit(
                StoreVisit(
                    dsfId = user.id,
                    dsfUsername = user.username,
                    baseStation = user.baseStation,
                    workingArea = area,
                    storeId = store.id,
                    storeName = store.name,
                    timestamp = timestamp,
                    latitude = _currentLatitude.value,
                    longitude = _currentLongitude.value,
                    address = _currentAddress.value,
                    photoBase64 = _capturedPhoto.value,
                    hasOrder = hasOrder,
                    totalOrderValue = totalValue
                )
            )

            // Insert order items referencing this visit ID
            if (hasOrder) {
                for (item in orderedItems) {
                    repository.insertOrderItem(item.copy(visitId = visitId))
                }
            }

            // Reset workflow states for next visit
            _selectedMedicalStore.value = null
            _locationShared.value = false
            _capturedPhoto.value = null
            _hasOrderSelection.value = null
            _orderQuantities.value = emptyMap()
            
            // Switch tab to Sales so they see the updated analytics
            _dsfTab.value = DsfTab.SALES
        }
    }

    // Admin action: Create DSF
    fun createDsfUser() {
        _adminErrorMessage.value = null
        _adminSuccessMessage.value = null
        val username = _newDsfUsername.value.trim()
        val password = _newDsfPassword.value.trim()
        val station = _newDsfBaseStation.value

        if (username.isEmpty() || password.isEmpty()) {
            _adminErrorMessage.value = "Username and password cannot be empty"
            return
        }

        viewModelScope.launch {
            val existing = repository.getDsfUserByUsername(username)
            if (existing != null) {
                _adminErrorMessage.value = "Username '$username' already exists"
                return@launch
            }

            repository.insertDsfUser(
                DsfUser(
                    username = username,
                    password = password,
                    baseStation = station
                )
            )

            _adminSuccessMessage.value = "DSF User '$username' created successfully"
            _newDsfUsername.value = ""
            _newDsfPassword.value = ""
        }
    }

    // Generate mock coordinate details for Pakistani towns to ensure excellent local data styling
    private fun generateMockLocation(area: String): Triple<Double, Double, String> {
        val baseCoords = mapOf(
            "tando allahyar" to Pair(25.4605, 68.7158),
            "matli" to Pair(25.0425, 68.6558),
            "tando jam" to Pair(25.4281, 68.5276),
            "saddar" to Pair(25.3924, 68.3737),
            "qasimabad" to Pair(25.4012, 68.3312),
            "jail road" to Pair(25.3941, 68.3582),
            "thana bhola khan" to Pair(25.4358, 67.8424),
            "kotri" to Pair(25.3703, 68.3117),
            "latifabad" to Pair(25.3622, 68.3421),
            "matyari" to Pair(25.5968, 68.4419),
            "saeedabad" to Pair(25.9189, 68.3846),
            "hala" to Pair(25.8114, 68.4216),
            "bhit shah" to Pair(25.8071, 68.4905),
            "shahdadpur" to Pair(25.9431, 68.6253),
            "tando adam" to Pair(25.7682, 68.6586),
            "sanghar" to Pair(26.0464, 68.9481),
            "badin" to Pair(24.6558, 68.8383),
            "talhar" to Pair(24.8761, 68.8122),
            "tando bhago" to Pair(24.7915, 68.9625),
            "hospital raod" to Pair(26.2442, 68.4110),
            "sakrand raod" to Pair(26.1364, 68.2652),
            "masjid raod" to Pair(26.2490, 68.4061),
            "sakran" to Pair(26.1310, 68.2701),
            "qazi ahmed" to Pair(26.2445, 67.9620),
            "moro" to Pair(26.6669, 68.0125),
            "dulat pur" to Pair(26.5021, 67.9715),
            "nawab ali muhammad" to Pair(26.2811, 68.4523),
            "daur" to Pair(26.3312, 68.5615),
            "bhadhi" to Pair(26.3815, 68.4212),
            "padidan" to Pair(26.9063, 68.2813),
            "baria raod" to Pair(26.8521, 68.3123),
            "akri" to Pair(26.7911, 68.4012),
            "korandi" to Pair(26.6512, 68.4523),
            "pirwasan" to Pair(26.5815, 68.3915),
            "shapur chakra" to Pair(26.1521, 68.7815),
            "khadro" to Pair(25.9912, 68.7212),
            "sarhari" to Pair(26.1115, 68.6115),
            "maqsodo" to Pair(25.8925, 68.8115),
            "karnal 60mail" to Pair(26.0912, 68.4812),
            "manwabad" to Pair(26.2612, 68.3912),
            "old nawabshah" to Pair(26.2425, 68.3823),
            "khipro" to Pair(25.8284, 69.3776),
            "degree" to Pair(25.1382, 69.1325),
            "jhudoo" to Pair(25.0212, 69.2981),
            "shadi pali" to Pair(25.5681, 69.4125),
            "kgm" to Pair(25.4215, 69.2155),
            "sindhri" to Pair(25.7112, 69.1123),
            "nokot" to Pair(24.8482, 69.3512),
            "mpk city" to Pair(25.5276, 69.0125),
            "noshero city" to Pair(26.8439, 68.1215),
            "kardairo" to Pair(26.8925, 68.1915),
            "bharia city" to Pair(26.8525, 68.3115),
            "tharo shah" to Pair(26.7825, 68.1125),
            "new jatoi" to Pair(26.8125, 67.9915),
            "mithyni" to Pair(26.9125, 68.0125),
            "umer kot city" to Pair(25.3615, 69.7315),
            "nangar parkar" to Pair(24.3615, 70.8215),
            "samro city" to Pair(25.1915, 69.4915),
            "mithi" to Pair(24.7415, 69.8015),
            "islam kot" to Pair(24.7015, 70.1815),
            "khokara par" to Pair(25.7115, 70.1915)
        )

        val coords = baseCoords[area.lowercase()] ?: Pair(25.3960, 68.3578)
        val lat = coords.first + (Math.random() - 0.5) * 0.002
        val lng = coords.second + (Math.random() - 0.5) * 0.002
        val addr = "Shop # ${10 + (Math.random() * 50).toInt()}, Main Bazar, $area, Sindh, Pakistan"

        return Triple(lat, lng, addr)
    }

    // Prepopulate database with complete demo data to support stunning analytics dashboards
    private suspend fun prepopulateData() {
        // 1. Insert DSF Users
        val dsf1Id = repository.insertDsfUser(DsfUser(username = "dsf_hyd1", password = "dsf123", baseStation = "HYDERABAD-1"))
        val dsf2Id = repository.insertDsfUser(DsfUser(username = "dsf_hyd2", password = "dsf123", baseStation = "Hyderabad-2"))
        val dsf3Id = repository.insertDsfUser(DsfUser(username = "dsf_nawab", password = "dsf123", baseStation = "Nawab Shah"))
        repository.insertDsfUser(DsfUser(username = "dsf_mpk", password = "dsf123", baseStation = "Mirpurkhas"))
        repository.insertDsfUser(DsfUser(username = "dsf_nf", password = "dsf123", baseStation = "Noshero Feroz"))
        repository.insertDsfUser(DsfUser(username = "dsf_uk", password = "dsf123", baseStation = "Umar Kot"))

        // 2. Insert Medical Stores
        // HYDERABAD-1
        val store1Id = repository.insertMedicalStore(MedicalStore(name = "Standard Pharmacy", baseStation = "HYDERABAD-1", workingArea = "Tando Allahyar"))
        val store2Id = repository.insertMedicalStore(MedicalStore(name = "Madina Medicos", baseStation = "HYDERABAD-1", workingArea = "Tando Allahyar"))
        val store3Id = repository.insertMedicalStore(MedicalStore(name = "Tando Jam Care Pharmacy", baseStation = "HYDERABAD-1", workingArea = "Tando jam"))
        val store4Id = repository.insertMedicalStore(MedicalStore(name = "Citizen Chemist", baseStation = "HYDERABAD-1", workingArea = "Qasimabad"))

        // Hyderabad-2
        val store5Id = repository.insertMedicalStore(MedicalStore(name = "Al-Shafa Medicos", baseStation = "Hyderabad-2", workingArea = "Latifabad"))
        val store6Id = repository.insertMedicalStore(MedicalStore(name = "Kotri Drugstore", baseStation = "Hyderabad-2", workingArea = "Kotri"))
        val store7Id = repository.insertMedicalStore(MedicalStore(name = "Sanghar Pharmacy", baseStation = "Hyderabad-2", workingArea = "Sanghar"))

        // Nawab Shah
        val store8Id = repository.insertMedicalStore(MedicalStore(name = "Central Hospital Pharmacy", baseStation = "Nawab Shah", workingArea = "Hospital raod"))
        val store9Id = repository.insertMedicalStore(MedicalStore(name = "Sakrand Drug Agency", baseStation = "Nawab Shah", workingArea = "Sakrand raod"))
    }
}
