package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DsfUser
import com.example.data.MedicalStore
import com.example.data.OrderItem
import com.example.data.StoreVisit
import com.example.ui.theme.*
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminHomeScreen(
    viewModel: SalesViewModel,
    modifier: Modifier = Modifier
) {
    val activeTab by viewModel.adminTab.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "ADMIN SALES PORTAL",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            text = "NATIONAL SALES MONITORING & AUDITS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.logout() }) {
                        Icon(Icons.Filled.Logout, contentDescription = "Logout", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = GoogleBlue)
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = activeTab == AdminTab.MONITOR,
                    onClick = { viewModel.setAdminTab(AdminTab.MONITOR) },
                    icon = { Icon(Icons.Filled.Visibility, contentDescription = "Monitor Tab") },
                    label = { Text("MONITORING", fontWeight = FontWeight.Bold, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GoogleBlue,
                        selectedTextColor = GoogleBlue,
                        indicatorColor = GoogleBlueLight
                    )
                )
                NavigationBarItem(
                    selected = activeTab == AdminTab.SALES,
                    onClick = { viewModel.setAdminTab(AdminTab.SALES) },
                    icon = { Icon(Icons.Filled.PieChart, contentDescription = "Dashboard Tab") },
                    label = { Text("DASHBOARD", fontWeight = FontWeight.Bold, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GoogleBlue,
                        selectedTextColor = GoogleBlue,
                        indicatorColor = GoogleBlueLight
                    )
                )
                NavigationBarItem(
                    selected = activeTab == AdminTab.USERS,
                    onClick = { viewModel.setAdminTab(AdminTab.USERS) },
                    icon = { Icon(Icons.Filled.GroupAdd, contentDescription = "Users Tab") },
                    label = { Text("TEAM", fontWeight = FontWeight.Bold, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GoogleBlue,
                        selectedTextColor = GoogleBlue,
                        indicatorColor = GoogleBlueLight
                    )
                )
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                AdminTab.MONITOR -> AdminMonitorTab(viewModel)
                AdminTab.SALES -> AdminSalesTab(viewModel)
                AdminTab.USERS -> AdminUsersTab(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminMonitorTab(viewModel: SalesViewModel) {
    val allVisits by viewModel.allVisits.collectAsState()
    val dsfUsers by viewModel.dsfUsers.collectAsState()
    val selectedDsfId by viewModel.adminSelectedDsfFilter.collectAsState()

    var isDsfDropdownExpanded by remember { mutableStateOf(false) }
    val decimalFormat = DecimalFormat("#,##0.00")
    val dateFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())

    // Filtered Visits
    val filteredVisits = remember(allVisits, selectedDsfId) {
        if (selectedDsfId == null) allVisits
        else allVisits.filter { it.dsfId == selectedDsfId }
    }

    // Calculations
    val totalVisited = filteredVisits.size
    val productiveVisited = filteredVisits.count { it.hasOrder }
    val totalBookedValue = filteredVisits.sumOf { it.totalOrderValue }
    val productivityPercent = if (totalVisited > 0) (productiveVisited.toFloat() / totalVisited) * 100 else 0f

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "LIVE FIELD MONITORING",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = GoogleTextDark
            )
            Spacer(modifier = Modifier.height(12.dp))

            // DSF Dropdown filter
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "FILTER BY DSF:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = GoogleSlate,
                    modifier = Modifier.padding(end = 12.dp)
                )

                ExposedDropdownMenuBox(
                    expanded = isDsfDropdownExpanded,
                    onExpandedChange = { isDsfDropdownExpanded = !isDsfDropdownExpanded },
                    modifier = Modifier.weight(1f)
                ) {
                    val currentFilterText = if (selectedDsfId == null) "ALL TEAM MEMBERS" 
                    else dsfUsers.find { it.id == selectedDsfId }?.username?.uppercase(Locale.getDefault()) ?: "ALL TEAM MEMBERS"

                    OutlinedTextField(
                        value = currentFilterText,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isDsfDropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoogleBlue,
                            unfocusedBorderColor = Color.LightGray
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = isDsfDropdownExpanded,
                        onDismissRequest = { isDsfDropdownExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("ALL TEAM MEMBERS", fontWeight = FontWeight.Bold) },
                            onClick = {
                                viewModel.setAdminSelectedDsfFilter(null)
                                isDsfDropdownExpanded = false
                            }
                        )
                        dsfUsers.forEach { user ->
                            DropdownMenuItem(
                                text = { Text("${user.username.uppercase(Locale.getDefault())} (${user.baseStation.uppercase(Locale.getDefault())})", fontWeight = FontWeight.Bold) },
                                onClick = {
                                    viewModel.setAdminSelectedDsfFilter(user.id)
                                    isDsfDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Audit KPI Stats row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = GoogleBlueLight),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("VISITED", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoogleSlate)
                        Text("$totalVisited STORES", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = GoogleBlueDark)
                    }
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = GoogleGreenLight),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("PRODUCTIVE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoogleSlate)
                        Text("$productiveVisited STORES", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = GoogleGreen)
                    }
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = GoogleTealLight),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("EFFICIENCY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoogleSlate)
                        Text("${String.format("%.1f", productivityPercent)}%", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = GoogleTeal)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Total Booking
            Card(
                colors = CardDefaults.cardColors(containerColor = GoogleBg),
                border = borderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("TOTAL ORDERS BOOKED", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoogleSlate)
                        Text("PKR ${decimalFormat.format(totalBookedValue)}", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = GoogleBlue)
                    }
                    Icon(Icons.Filled.ShoppingCart, contentDescription = "Cart", tint = GoogleBlue, modifier = Modifier.size(28.dp))
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "LIVE AUDIT ACTIVITIES LOG",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = GoogleTextDark,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        if (filteredVisits.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "NO FIELD ACTIVITIES RECORDED YET",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoogleSlate,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(filteredVisits) { visit ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column {
                                Text(
                                    text = visit.storeName.uppercase(Locale.getDefault()),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 14.sp,
                                    color = GoogleTextDark
                                )
                                Text(
                                    text = "DSF REP: ${visit.dsfUsername.uppercase(Locale.getDefault())} | BASE STATION: ${visit.baseStation.uppercase(Locale.getDefault())}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoogleBlueDark
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (visit.hasOrder) GoogleGreenLight else GoogleLightGray)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (visit.hasOrder) "PRODUCTIVE" else "NON-PROD",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 10.sp,
                                    color = if (visit.hasOrder) GoogleGreen else GoogleSlate
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "WORKING AREA: ${visit.workingArea.uppercase(Locale.getDefault())}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoogleSlate
                            )
                            Text(
                                text = dateFormat.format(Date(visit.timestamp)).uppercase(Locale.getDefault()),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoogleSlate
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Divider(color = Color.LightGray.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(8.dp))

                        // Address & Geolocation Map representation
                        Row(
                            verticalAlignment = Alignment.Top,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                Icons.Filled.PinDrop,
                                contentDescription = "Map Location",
                                tint = GoogleRed,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = "GEOTAGGED ADDRESS:",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = GoogleTextDark
                                )
                                Text(
                                    text = visit.address.uppercase(Locale.getDefault()),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoogleSlate,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "GPS COORDINATES: LAT ${String.format("%.5f", visit.latitude)}, LNG ${String.format("%.5f", visit.longitude)}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoogleBlue
                                )
                            }
                        }

                        // Storefront Picture thumbnail simulator
                        visit.photoBase64?.let { photo ->
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(GoogleLightGray)
                                    .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(GoogleBlueLight, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Filled.Store,
                                        contentDescription = "Storefront Picture",
                                        tint = GoogleBlue
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "STOREFRONT PICTURE AUDIT",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = GoogleTextDark
                                    )
                                    Text(
                                        text = "VERIFIED IMAGE TEMPLATE: ${photo.uppercase(Locale.getDefault())}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GoogleSlate
                                    )
                                }
                            }
                        }

                        // Show Order details in nested card
                        if (visit.hasOrder && visit.totalOrderValue > 0) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = GoogleGreenLight.copy(alpha = 0.3f)),
                                border = borderStroke(1.dp, GoogleGreen.copy(alpha = 0.3f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "ORDER SUMMARY BOOKED",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = GoogleGreen
                                        )
                                        Text(
                                            text = "TOTAL VALUE: PKR ${decimalFormat.format(visit.totalOrderValue)}",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = GoogleGreen
                                        )
                                    }
                                    Icon(Icons.Filled.CheckCircle, contentDescription = "Ok", tint = GoogleGreen)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminSalesTab(viewModel: SalesViewModel) {
    val allVisits by viewModel.allVisits.collectAsState()
    val allOrderItems by viewModel.allOrderItems.collectAsState()
    val dsfUsers by viewModel.dsfUsers.collectAsState()

    val totalBookings = allVisits.sumOf { it.totalOrderValue }
    val totalPacks = allOrderItems.sumOf { it.quantity }

    val decimalFormat = DecimalFormat("#,##0.00")

    // Grouping by product
    val productAggregates = remember(allOrderItems) {
        allOrderItems.groupBy { it.productName }
            .map { (name, items) ->
                val qty = items.sumOf { it.quantity }
                val value = items.sumOf { it.totalPrice }
                Triple(name, qty, value)
            }.sortedByDescending { it.third }
    }

    // Grouping sales per DSF user for charts
    val dsfSalesSplit = remember(allVisits, dsfUsers) {
        dsfUsers.map { user ->
            val sales = allVisits.filter { it.dsfId == user.id }.sumOf { it.totalOrderValue }
            Pair(user.username, sales)
        }.filter { it.second > 0 }.sortedByDescending { it.second }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "NATIONAL SALES DASHBOARD",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = GoogleTextDark
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Summary Stats Card
            Card(
                colors = CardDefaults.cardColors(containerColor = GoogleBlue),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "TOTAL GROSS SALES REVENUE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                    Text(
                        text = "PKR ${decimalFormat.format(totalBookings)}",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = Color.White.copy(alpha = 0.3f))
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("TOTAL VOLUME SOLD", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.8f))
                            Text("$totalPacks PACKS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("ACTIVE SALES FORCE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.8f))
                            Text("${dsfUsers.size} DSFS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Canvas drawing for visual Sales Split Pie/Donut Chart
            if (dsfSalesSplit.isNotEmpty()) {
                Text(
                    text = "SALES CONTRIBUTION PER DSF",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = GoogleTextDark,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val colors = listOf(GoogleBlue, GoogleTeal, GoogleGreen, GoogleOrange, GoogleSlate, GoogleRed)
                        val totalSalesVal = dsfSalesSplit.sumOf { it.second }

                        // Draw Pie Chart inside Canvas
                        Box(
                            modifier = Modifier
                                .size(160.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                var startAngle = -90f
                                dsfSalesSplit.forEachIndexed { index, item ->
                                    val sweepAngle = (item.second.toFloat() / totalSalesVal.toFloat()) * 360f
                                    val color = colors.getOrElse(index) { GoogleSlate }
                                    
                                    drawArc(
                                        color = color,
                                        startAngle = startAngle,
                                        sweepAngle = sweepAngle,
                                        useCenter = false,
                                        style = Stroke(width = 30f),
                                        size = Size(size.width, size.height)
                                    )
                                    startAngle += sweepAngle
                                }
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("SALES SHARE", fontSize = 11.sp, color = GoogleSlate, fontWeight = FontWeight.ExtraBold)
                                Text("SPLIT", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = GoogleBlueDark)
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Chart Legend
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            dsfSalesSplit.forEachIndexed { index, item ->
                                val color = colors.getOrElse(index) { GoogleSlate }
                                val percentage = (item.second / totalSalesVal) * 100

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(12.dp)
                                                .clip(CircleShape)
                                                .background(color)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = item.first.uppercase(Locale.getDefault()), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = GoogleTextDark)
                                    }
                                    Text(
                                        text = "PKR ${decimalFormat.format(item.second)} (${String.format("%.1f", percentage)}%)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = GoogleSlate
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Sub title
            Text(
                text = "NATIONAL PRODUCT SALES PERFORMANCE",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = GoogleTextDark,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        if (productAggregates.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "NO BOOKING TRANSACTIONS RECORDED YET",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoogleSlate,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(productAggregates) { (prodName, qty, value) ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(1.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.5f)) {
                            Text(
                                text = prodName.uppercase(Locale.getDefault()),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = GoogleTextDark
                             )
                            Text(
                                text = "$qty UNITS BOOKED NATIONALLY",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoogleSlate
                            )
                        }
                        Text(
                            text = "PKR ${decimalFormat.format(value)}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = GoogleTeal,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.End
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminUsersTab(viewModel: SalesViewModel) {
    val dsfUsers by viewModel.dsfUsers.collectAsState()
    val allVisits by viewModel.allVisits.collectAsState()

    val newDsfUsername by viewModel.newDsfUsername.collectAsState()
    val newDsfPassword by viewModel.newDsfPassword.collectAsState()
    val newDsfBaseStation by viewModel.newDsfBaseStation.collectAsState()
    val successMsg by viewModel.adminSuccessMessage.collectAsState()
    val errMsg by viewModel.adminErrorMessage.collectAsState()

    var isStationExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "MANAGE DISTRICT SALES FORCE",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = GoogleTextDark
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Create DSF Account Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "REGISTER NEW DSF USER",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        color = GoogleBlue
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Messages
                    successMsg?.let { msg ->
                        Text(
                            text = msg.uppercase(Locale.getDefault()),
                            color = GoogleGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 10.dp)
                        )
                    }
                    errMsg?.let { msg ->
                        Text(
                            text = msg.uppercase(Locale.getDefault()),
                            color = GoogleRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 10.dp)
                        )
                    }

                    // Username
                    Text("DSF USERNAME / ID", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = newDsfUsername,
                        onValueChange = { viewModel.setNewDsfUsername(it) },
                        placeholder = { Text("E.G. DSF_HYD1") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoogleBlue,
                            unfocusedBorderColor = Color.LightGray
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Password
                    Text("DSF PASSWORD", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = newDsfPassword,
                        onValueChange = { viewModel.setNewDsfPassword(it) },
                        placeholder = { Text("ENTER PASSWORD") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoogleBlue,
                            unfocusedBorderColor = Color.LightGray
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Base Station Dropdown selection
                    Text("ASSIGN BASE STATION", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))

                    ExposedDropdownMenuBox(
                        expanded = isStationExpanded,
                        onExpandedChange = { isStationExpanded = !isStationExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = newDsfBaseStation.uppercase(Locale.getDefault()),
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isStationExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoogleBlue,
                                unfocusedBorderColor = Color.LightGray
                            )
                        )
                        ExposedDropdownMenu(
                            expanded = isStationExpanded,
                            onDismissRequest = { isStationExpanded = false }
                        ) {
                            viewModel.baseStationsMap.keys.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text(station.uppercase(Locale.getDefault()), fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        viewModel.setNewDsfBaseStation(station)
                                        isStationExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Button Create
                    Button(
                        onClick = { viewModel.createDsfUser() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GoogleBlue),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Icon(Icons.Filled.PersonAdd, contentDescription = "Add Person")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("REGISTER DSF ACCOUNT", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "REGISTERED SALES FORCE (${dsfUsers.size} MEMBERS)",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = GoogleTextDark,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        items(dsfUsers) { user ->
            val visitCount = allVisits.count { it.dsfId == user.id }
            val salesValue = allVisits.filter { it.dsfId == user.id }.sumOf { it.totalOrderValue }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                border = borderStroke(1.dp, Color.LightGray.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(GoogleBlueLight, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Person, contentDescription = "DSF Rep", tint = GoogleBlue)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = user.username.uppercase(Locale.getDefault()),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                color = GoogleTextDark
                            )
                            Text(
                                text = "BASE: ${user.baseStation.uppercase(Locale.getDefault())}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoogleSlate
                            )
                            Text(
                                text = "PASSWORD: ${user.password.uppercase(Locale.getDefault())}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoogleSlate
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "$visitCount AUDITS",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp,
                            color = GoogleTextDark
                        )
                        Text(
                            text = "PKR ${DecimalFormat("#,##0").format(salesValue)}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = GoogleTeal
                        )
                    }
                }
            }
        }
    }
}
