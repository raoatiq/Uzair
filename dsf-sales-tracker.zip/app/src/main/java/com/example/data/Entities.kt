package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "dsf_users")
data class DsfUser(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val password: String,
    val baseStation: String
)

@Entity(tableName = "medical_stores")
data class MedicalStore(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val baseStation: String,
    val workingArea: String
)

@Entity(tableName = "store_visits")
data class StoreVisit(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dsfId: Long,
    val dsfUsername: String,
    val baseStation: String,
    val workingArea: String,
    val storeId: Long,
    val storeName: String,
    val timestamp: Long,
    val latitude: Double,
    val longitude: Double,
    val address: String,
    val photoBase64: String?, // Simulated picture
    val hasOrder: Boolean,
    val totalOrderValue: Double
)

@Entity(tableName = "order_items")
data class OrderItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val visitId: Long,
    val dsfId: Long,
    val storeName: String,
    val productName: String,
    val quantity: Int,
    val tradePrice: Double,
    val totalPrice: Double,
    val timestamp: Long
)
