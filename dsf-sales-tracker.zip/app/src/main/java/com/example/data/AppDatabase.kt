package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SalesDao {
    // DSF Users
    @Query("SELECT * FROM dsf_users")
    fun getAllDsfUsers(): Flow<List<DsfUser>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDsfUser(user: DsfUser): Long

    @Query("SELECT * FROM dsf_users WHERE username = :username LIMIT 1")
    suspend fun getDsfUserByUsername(username: String): DsfUser?

    // Medical Stores
    @Query("SELECT * FROM medical_stores")
    fun getAllMedicalStores(): Flow<List<MedicalStore>>

    @Query("SELECT * FROM medical_stores WHERE baseStation = :baseStation AND workingArea = :workingArea")
    fun getStoresByArea(baseStation: String, workingArea: String): Flow<List<MedicalStore>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedicalStore(store: MedicalStore): Long

    // Store Visits
    @Query("SELECT * FROM store_visits ORDER BY timestamp DESC")
    fun getAllVisits(): Flow<List<StoreVisit>>

    @Query("SELECT * FROM store_visits WHERE dsfId = :dsfId ORDER BY timestamp DESC")
    fun getVisitsByDsf(dsfId: Long): Flow<List<StoreVisit>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStoreVisit(visit: StoreVisit): Long

    // Order Items
    @Query("SELECT * FROM order_items WHERE visitId = :visitId")
    suspend fun getOrderItemsByVisit(visitId: Long): List<OrderItem>

    @Query("SELECT * FROM order_items ORDER BY timestamp DESC")
    fun getAllOrderItems(): Flow<List<OrderItem>>

    @Query("SELECT * FROM order_items WHERE dsfId = :dsfId ORDER BY timestamp DESC")
    fun getOrderItemsByDsf(dsfId: Long): Flow<List<OrderItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderItem(item: OrderItem): Long
}

@Database(
    entities = [DsfUser::class, MedicalStore::class, StoreVisit::class, OrderItem::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun salesDao(): SalesDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "sales_tracker_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
