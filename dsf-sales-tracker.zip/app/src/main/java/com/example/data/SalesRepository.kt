package com.example.data

import kotlinx.coroutines.flow.Flow

class SalesRepository(private val salesDao: SalesDao) {
    val allDsfUsers: Flow<List<DsfUser>> = salesDao.getAllDsfUsers()
    val allMedicalStores: Flow<List<MedicalStore>> = salesDao.getAllMedicalStores()
    val allVisits: Flow<List<StoreVisit>> = salesDao.getAllVisits()
    val allOrderItems: Flow<List<OrderItem>> = salesDao.getAllOrderItems()

    fun getStoresByArea(baseStation: String, workingArea: String): Flow<List<MedicalStore>> =
        salesDao.getStoresByArea(baseStation, workingArea)

    fun getVisitsByDsf(dsfId: Long): Flow<List<StoreVisit>> =
        salesDao.getVisitsByDsf(dsfId)

    fun getOrderItemsByDsf(dsfId: Long): Flow<List<OrderItem>> =
        salesDao.getOrderItemsByDsf(dsfId)

    suspend fun getDsfUserByUsername(username: String): DsfUser? =
        salesDao.getDsfUserByUsername(username)

    suspend fun insertDsfUser(user: DsfUser): Long =
        salesDao.insertDsfUser(user)

    suspend fun insertMedicalStore(store: MedicalStore): Long =
        salesDao.insertMedicalStore(store)

    suspend fun insertStoreVisit(visit: StoreVisit): Long =
        salesDao.insertStoreVisit(visit)

    suspend fun insertOrderItem(item: OrderItem): Long =
        salesDao.insertOrderItem(item)
}
